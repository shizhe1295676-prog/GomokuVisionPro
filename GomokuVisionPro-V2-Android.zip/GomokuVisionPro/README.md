# Gomoku Vision Pro V2

Android 原生五子棋截图识别与实时屏幕分析项目。

## 功能
- Android Photo Picker 导入截图识别。
- Android MediaProjection 用户授权后实时采集屏幕。
- 前台服务运行屏幕采集，检测棋局变化后广播更新。
- OpenCV HoughLinesP 网格检测与 15×15 棋盘拟合。
- 棋子黑白分类、棋局矩阵重建、下一手推断。
- 本地 AI：候选点、立即胜/防守、Negamax、Alpha-Beta、迭代加深、置换表、棋型评估。
- 棋盘预览与绿色圆圈推荐落点显示。

## 环境
- Android Studio Ladybug 或更新版本
- JDK 17
- Android SDK 35
- Gradle 8.9
- Android Gradle Plugin 8.7.3

## 运行
1. 解压 ZIP，用 Android Studio 打开项目根目录。
2. 等待 Gradle Sync。
3. 连接 Android 设备，点击 Run。
4. 可先导入截图测试；或点击「开始实时屏幕识别」。
5. Android 系统弹出屏幕共享授权时，选择开始共享。
6. 切换到五子棋应用。检测到棋盘状态变化时，Gomoku Vision Pro 会更新棋盘。
7. 点击「AI 分析最佳落点」，绿色圆圈显示推荐坐标。
8. 点击「停止实时识别」结束屏幕采集。

## Android 权限与隐私
屏幕捕获必须由用户通过 Android MediaProjection 系统弹窗明确授权。应用以 Android 前台服务持续采集，并显示系统通知。屏幕帧在设备本地处理，不上传服务器。不要在不需要时保持采集；停止时点击应用内停止按钮。

## 当前识别实现与限制
本版本提供可运行的实时采集链路，但识别算法仍是通用规则网格拟合原型：
- 默认目标是完整、正视、无遮挡的 15×15 棋盘。
- 当前网格拟合使用 HoughLinesP 直线检测和间距一致性评分。
- 当前棋子分类用交叉点中心灰度阈值；不同木纹、阴影、发光效果可能造成误判。
- 棋盘被顶部玩家信息、广告、动画或弹窗遮挡时，可能无法拟合；需要进一步增加 ROI 自动定位、透视四角检测与交互式校准。
- 实时服务每约 1.2 秒分析一帧，并仅在棋盘矩阵变化时发送更新。
- 部分 Android 厂商系统可能限制后台屏幕采集；请保持应用前台并按系统提示授权。

## AI 说明
AI 为启发式搜索原型，包含 Alpha-Beta、迭代加深、局部候选点和基础棋型评分。尚未实现完整 VCF/VCT 威胁空间求解、开局库、并行搜索或专业竞赛级规则适配。当前代码不自动点击或操作第三方游戏。

## 结构
- `BoardDetector.kt`：棋盘与棋子视觉识别
- `ScreenCaptureService.kt`：MediaProjection 实时采集
- `BoardPreviewView.kt`：棋盘与推荐点绘制
- `GomokuEngine.kt`：AI 搜索引擎
- `MainActivity.kt`：应用界面、授权、流程调度
- `Stone.kt`：棋局数据结构
