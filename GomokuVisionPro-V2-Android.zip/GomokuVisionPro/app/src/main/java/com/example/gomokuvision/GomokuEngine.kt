package com.example.gomokuvision

import kotlin.math.*

/**
 * Practical local Gomoku engine:
 * - tactical win/block checks
 * - radius-2 candidate generation
 * - iterative-deepening negamax with alpha-beta pruning
 * - transposition table keyed by a deterministic board hash
 * - pattern-based evaluation
 *
 * This is a strong heuristic engine, not a tournament proof-number solver.
 */
class GomokuEngine(
    private val maxDepth: Int = 4,
    private val nodeLimit: Long = 180_000
) {
    private var nodes = 0L
    private val table = HashMap<Long, TTEntry>()
    private data class TTEntry(val depth: Int, val value: Int, val best: Int)

    fun bestMove(board: BoardState, side: Stone = board.next): Move? {
        require(side != Stone.EMPTY)
        val candidates = candidates(board)
        if (candidates.isEmpty()) return null
        // Immediate win, then immediate block.
        for (p in candidates) {
            board[p.first, p.second] = side
            val win = wins(board, p.first, p.second, side)
            board[p.first, p.second] = Stone.EMPTY
            if (win) return Move(p.first, p.second, 1_000_000_000L, "立即形成五连")
        }
        for (p in candidates) {
            board[p.first, p.second] = side.opponent()
            val opponentWin = wins(board, p.first, p.second, side.opponent())
            board[p.first, p.second] = Stone.EMPTY
            if (opponentWin) return Move(p.first, p.second, 900_000_000L, "阻止对手立即五连")
        }

        nodes = 0
        var best = candidates.first()
        var bestScore = Int.MIN_VALUE
        for (depth in 1..maxDepth) {
            var alpha = -WIN; var localBest = best; var localScore = Int.MIN_VALUE
            val ordered = candidates.sortedByDescending { moveOrdering(board, it.first, it.second, side) }
            for ((r, c) in ordered) {
                if (nodes >= nodeLimit) break
                board[r, c] = side
                val score = -search(board, depth - 1, -WIN, -alpha, side.opponent(), 1)
                board[r, c] = Stone.EMPTY
                if (score > localScore) { localScore = score; localBest = r to c }
                alpha = max(alpha, score)
            }
            if (localScore > bestScore) { bestScore = localScore; best = localBest }
            if (nodes >= nodeLimit) break
        }
        val (r, c) = best
        board[r, c] = side
        val attack = evaluatePoint(board, r, c, side)
        board[r, c] = side.opponent()
        val defense = evaluatePoint(board, r, c, side.opponent())
        board[r, c] = Stone.EMPTY
        val reason = when {
            attack >= 100_000 -> "强力进攻：制造必应威胁"
            defense >= 100_000 -> "优先防守：化解对手强威胁"
            attack > defense * 1.2 -> "进攻优先：扩大己方棋型"
            else -> "攻防均衡：控制关键交叉点"
        }
        return Move(r, c, bestScore.toLong(), "$reason（搜索节点 $nodes）")
    }

    private fun search(b: BoardState, depth: Int, alphaIn: Int, beta: Int, side: Stone, ply: Int): Int {
        nodes++
        if (nodes >= nodeLimit) return evaluate(b, side)
        val hash = hash(b, side)
        val cached = table[hash]
        if (cached != null && cached.depth >= depth) return cached.value
        if (depth == 0) return evaluate(b, side)
        var alpha = alphaIn
        val moves = candidates(b).sortedByDescending { moveOrdering(b, it.first, it.second, side) }
        if (moves.isEmpty()) return 0
        var best = -WIN
        var bestIndex = -1
        for ((r, c) in moves) {
            b[r, c] = side
            val score = if (wins(b, r, c, side)) WIN - ply
                else -search(b, depth - 1, -beta, -alpha, side.opponent(), ply + 1)
            b[r, c] = Stone.EMPTY
            if (score > best) { best = score; bestIndex = r * b.size + c }
            alpha = max(alpha, score)
            if (alpha >= beta || nodes >= nodeLimit) break
        }
        table[hash] = TTEntry(depth, best, bestIndex)
        return best
    }

    private fun candidates(b: BoardState): List<Pair<Int, Int>> {
        val out = mutableListOf<Pair<Int, Int>>()
        val seen = HashSet<Int>()
        var occupied = false
        for (r in 0 until b.size) for (c in 0 until b.size) if (b[r,c] != Stone.EMPTY) {
            occupied = true
            for (dr in -2..2) for (dc in -2..2) {
                val nr = r + dr; val nc = c + dc
                if (nr in 0 until b.size && nc in 0 until b.size && b[nr,nc] == Stone.EMPTY) {
                    val id = nr * b.size + nc
                    if (seen.add(id)) out += nr to nc
                }
            }
        }
        if (!occupied) return listOf(b.size / 2 to b.size / 2)
        return out
    }

    private fun evaluate(b: BoardState, side: Stone): Int {
        var score = 0
        for (r in 0 until b.size) for (c in 0 until b.size) {
            val s = b[r,c]
            if (s == Stone.EMPTY) continue
            val v = evaluatePoint(b, r, c, s)
            score += if (s == side) v else -v
        }
        return score
    }

    private fun evaluatePoint(b: BoardState, r: Int, c: Int, s: Stone): Int {
        if (s == Stone.EMPTY) return 0
        val dirs = arrayOf(0 to 1, 1 to 0, 1 to 1, 1 to -1)
        var total = 0
        for ((dr, dc) in dirs) {
            var count = 1; var open = 0
            for (sign in listOf(-1, 1)) {
                var rr = r + dr * sign; var cc = c + dc * sign
                var steps = 0
                while (rr in 0 until b.size && cc in 0 until b.size && b[rr,cc] == s && steps < 4) {
                    count++; steps++; rr += dr * sign; cc += dc * sign
                }
                if (rr in 0 until b.size && cc in 0 until b.size && b[rr,cc] == Stone.EMPTY) open++
            }
            val value = when {
                count >= 5 -> 10_000_000
                count == 4 && open == 2 -> 500_000
                count == 4 && open == 1 -> 80_000
                count == 3 && open == 2 -> 12_000
                count == 3 && open == 1 -> 1_500
                count == 2 && open == 2 -> 400
                count == 2 && open == 1 -> 80
                else -> count * 5
            }
            total += value
        }
        return total
    }

    private fun moveOrdering(b: BoardState, r: Int, c: Int, s: Stone): Int {
        b[r, c] = s
        val attack = evaluatePoint(b, r, c, s)
        b[r, c] = s.opponent()
        val defense = evaluatePoint(b, r, c, s.opponent())
        b[r, c] = Stone.EMPTY
        return attack * 2 + defense
    }

    private fun wins(b: BoardState, r: Int, c: Int, s: Stone): Boolean {
        for ((dr, dc) in arrayOf(0 to 1, 1 to 0, 1 to 1, 1 to -1)) {
            var n = 1
            for (sign in listOf(-1, 1)) {
                var rr = r + dr * sign; var cc = c + dc * sign
                while (rr in 0 until b.size && cc in 0 until b.size && b[rr,cc] == s) {
                    n++; rr += dr * sign; cc += dc * sign
                }
            }
            if (n >= 5) return true
        }
        return false
    }

    private fun hash(b: BoardState, side: Stone): Long {
        var h = if (side == Stone.BLACK) 0x5A5A5A5AL else 0xA5A5A5A5L
        for (i in b.cells.indices) {
            val v = b.cells[i].code.toLong()
            if (v != 0L) h = h xor ((i.toLong() + 1L) * -7046029254386353131L).rotateLeft((v * 11).toInt())
        }
        return h
    }

    private fun Long.rotateLeft(bits: Int): Long = (this shl (bits and 63)) or (this ushr (64 - (bits and 63)))
    companion object { private const val WIN = 1_100_000_000 }
}
