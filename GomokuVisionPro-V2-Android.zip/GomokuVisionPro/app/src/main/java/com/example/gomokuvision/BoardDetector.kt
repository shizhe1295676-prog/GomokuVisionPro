package com.example.gomokuvision

import android.graphics.Bitmap
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc
import kotlin.math.*

data class DetectionResult(
    val board: BoardState,
    val corners: List<Point>,
    val confidence: Double,
    val message: String,
    val gridXs: List<Double>,
    val gridYs: List<Double>
)

/**
 * Screenshot-oriented detector. Finds long horizontal/vertical grid lines,
 * fits a regular 15-line lattice, then classifies the center patch of each crossing.
 * If automatic line fitting fails, the UI offers manual correction in a later iteration.
 */
object BoardDetector {
    fun detect(bitmap: Bitmap, size: Int = 15): DetectionResult {
        check(OpenCVLoader.initLocal()) { "OpenCV 初始化失败，请确认依赖已下载" }
        val rgba = Mat()
        Utils.bitmapToMat(bitmap.copy(Bitmap.Config.ARGB_8888, false), rgba)
        val gray = Mat()
        Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
        Imgproc.GaussianBlur(gray, gray, Size(3.0, 3.0), 0.0)
        val edges = Mat()
        Imgproc.Canny(gray, edges, 55.0, 150.0)
        val lines = Mat()
        val minLen = min(bitmap.width, bitmap.height) * 0.22
        Imgproc.HoughLinesP(edges, lines, 1.0, Math.PI / 180.0, 70, minLen, 12.0)

        val horizontal = mutableListOf<Pair<Double, Double>>()
        val vertical = mutableListOf<Pair<Double, Double>>()
        for (i in 0 until lines.rows()) {
            val v = lines.get(i, 0) ?: continue
            if (v.size < 4) continue
            val x1 = v[0]; val y1 = v[1]; val x2 = v[2]; val y2 = v[3]
            val dx = abs(x2 - x1); val dy = abs(y2 - y1)
            val len = hypot(dx, dy)
            if (len < minLen) continue
            if (dy < dx * 0.12) horizontal += ((y1 + y2) / 2.0) to len
            if (dx < dy * 0.12) vertical += ((x1 + x2) / 2.0) to len
        }
        val ys = fitGrid(horizontal, size)
        val xs = fitGrid(vertical, size)
        require(xs != null && ys != null) {
            "未能可靠定位完整棋盘网格。请使用完整、正视、无遮挡的棋盘截图。"
        }

        val board = BoardState(size)
        val spacing = min(medianGap(xs), medianGap(ys))
        for (r in 0 until size) for (c in 0 until size) {
            val x = xs[c].roundToInt().coerceIn(0, bitmap.width - 1)
            val y = ys[r].roundToInt().coerceIn(0, bitmap.height - 1)
            val cls = classify(gray, x, y, max(2, (spacing * 0.20).roundToInt()))
            board[r, c] = cls
        }
        val black = board.count(Stone.BLACK)
        val white = board.count(Stone.WHITE)
        board.next = if (black <= white) Stone.BLACK else Stone.WHITE
        val confidence = (0.55 + min(0.4, (xs.size + ys.size) / 75.0)).coerceIn(0.0, 0.95)
        rgba.release(); gray.release(); edges.release(); lines.release()
        return DetectionResult(
            board,
            listOf(Point(xs.first(), ys.first()), Point(xs.last(), ys.last())),
            confidence,
            "识别到 ${black} 枚黑棋、${white} 枚白棋；默认下一手：${if (board.next == Stone.BLACK) "黑棋" else "白棋"}",
            xs, ys
        )
    }

    private fun classify(gray: Mat, x: Int, y: Int, radius: Int): Stone {
        val x0 = (x - radius).coerceAtLeast(0)
        val y0 = (y - radius).coerceAtLeast(0)
        val x1 = (x + radius).coerceAtMost(gray.cols() - 1)
        val y1 = (y + radius).coerceAtMost(gray.rows() - 1)
        val patch = gray.submat(y0, y1 + 1, x0, x1 + 1)
        val mean = Core.mean(patch).`val`[0]
        patch.release()
        // Conservative thresholds avoid treating the tan wooden board as a stone.
        return when {
            mean < 82.0 -> Stone.BLACK
            mean > 222.0 -> Stone.WHITE
            else -> Stone.EMPTY
        }
    }

    private fun fitGrid(items: List<Pair<Double, Double>>, n: Int): List<Double>? {
        if (items.size < n) return null
        val sorted = items.sortedBy { it.first }
        val clusters = mutableListOf<MutableList<Pair<Double, Double>>>()
        for (item in sorted) {
            val last = clusters.lastOrNull()
            if (last == null || abs(last.map { it.first }.average() - item.first) > 5.0)
                clusters += mutableListOf(item)
            else last += item
        }
        val centers = clusters.map { g ->
            val total = g.sumOf { it.second }.coerceAtLeast(1.0)
            g.sumOf { it.first * it.second } / total
        }.sorted()
        if (centers.size < n) return null
        var best: List<Double>? = null
        var bestCost = Double.POSITIVE_INFINITY
        for (start in 0..centers.size - n) {
            val candidate = centers.subList(start, start + n)
            val gaps = candidate.zipWithNext { a, b -> b - a }
            val avg = gaps.average()
            if (avg <= 3.0) continue
            val variance = gaps.sumOf { (it - avg).pow(2) } / gaps.size
            val cost = variance / (avg * avg) + 0.00001 * candidate.first()
            if (cost < bestCost) { bestCost = cost; best = candidate.toList() }
        }
        return best?.takeIf { bestCost < 0.12 }
    }

    private fun medianGap(xs: List<Double>): Double {
        val gaps = xs.zipWithNext { a, b -> b - a }.sorted()
        return gaps[gaps.size / 2]
    }
}
