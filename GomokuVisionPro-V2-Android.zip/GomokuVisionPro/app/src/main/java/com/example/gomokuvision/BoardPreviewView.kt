package com.example.gomokuvision

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.view.View
import kotlin.math.min

class BoardPreviewView(context: Context) : View(context) {
    var state: BoardState? = null
        set(value) { field = value; invalidate() }
    var recommended: Pair<Int, Int>? = null
        set(value) { field = value; invalidate() }

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(130, 83, 43); strokeWidth = 1.4f }
    private val black = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(22, 22, 22); style = Paint.Style.FILL }
    private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(20, 160, 75); style = Paint.Style.STROKE; strokeWidth = 4f
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.DKGRAY; textSize = 26f; textAlign = Paint.Align.CENTER
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val b = state ?: return
        val pad = 24f
        val side = min(width, height).toFloat() - 2 * pad
        val left = (width - side) / 2f
        val top = (height - side) / 2f
        val gap = side / (b.size - 1)
        canvas.drawColor(Color.rgb(244, 220, 181))
        for (i in 0 until b.size) {
            val p = left + i * gap
            canvas.drawLine(p, top, p, top + side, line)
            val q = top + i * gap
            canvas.drawLine(left, q, left + side, q, line)
        }
        for (r in 0 until b.size) for (c in 0 until b.size) {
            val x = left + c * gap
            val y = top + r * gap
            when (b[r,c]) {
                Stone.BLACK -> canvas.drawCircle(x, y, gap * .34f, black)
                Stone.WHITE -> {
                    canvas.drawCircle(x, y, gap * .34f, white)
                    canvas.drawCircle(x, y, gap * .34f, line)
                }
                Stone.EMPTY -> Unit
            }
        }
        recommended?.let { (r, c) ->
            val x = left + c * gap
            val y = top + r * gap
            canvas.drawCircle(x, y, gap * .43f, ring)
            canvas.drawText("★", x, y - gap * .55f, label)
        }
    }
}
