package com.example.gomokuvision

enum class Stone(val code: Int) {
    EMPTY(0), BLACK(1), WHITE(2);
    fun opponent() = when (this) {
        BLACK -> WHITE
        WHITE -> BLACK
        EMPTY -> EMPTY
    }
}

data class Move(val row: Int, val col: Int, val score: Long, val reason: String)
data class BoardState(
    val size: Int = 15,
    val cells: Array<Stone> = Array(size * size) { Stone.EMPTY },
    var next: Stone = Stone.BLACK
) {
    operator fun get(r: Int, c: Int): Stone = cells[r * size + c]
    operator fun set(r: Int, c: Int, s: Stone) { cells[r * size + c] = s }
    fun copyBoard() = BoardState(size, cells.copyOf(), next)
    fun count(s: Stone) = cells.count { it == s }
}
