package com.example.gomokuvision

import android.app.Activity
import android.content.*
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private var bitmap: Bitmap? = null
    private var board: BoardState? = null
    private var recommended: Move? = null
    private lateinit var status: TextView
    private lateinit var boardView: BoardPreviewView
    private lateinit var details: TextView
    private lateinit var liveButton: Button

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) contentResolver.openInputStream(uri)?.use {
            bitmap = BitmapFactory.decodeStream(it)
            status.text = "图片已载入，正在识别…"
            detectImported()
        }
    }

    private val projectionConsent = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val service = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_DATA, result.data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
            liveButton.text = "停止实时识别"
            status.text = "实时识别已启动。请切换到五子棋游戏；检测到棋局变化后会自动更新。"
        } else status.text = "你取消了屏幕共享授权。"
    }

    private val boardReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val size = intent?.getIntExtra(ScreenCaptureService.EXTRA_SIZE, 15) ?: return
            val encoded = intent.getStringExtra(ScreenCaptureService.EXTRA_CELLS) ?: return
            if (encoded.length != size * size) return
            val cells = Array(size * size) { i ->
                when (encoded[i].digitToIntOrNull()) {
                    1 -> Stone.BLACK
                    2 -> Stone.WHITE
                    else -> Stone.EMPTY
                }
            }
            val next = if (intent.getIntExtra(ScreenCaptureService.EXTRA_NEXT, 1) == 2)
                Stone.WHITE else Stone.BLACK
            board = BoardState(size, cells, next)
            recommended = null
            runOnUiThread {
                boardView.state = board
                boardView.recommended = null
                status.text = intent.getStringExtra(ScreenCaptureService.EXTRA_MESSAGE) ?: "实时棋局已更新"
                details.text = "棋局已同步。点击「AI 分析」获取当前推荐落点。"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val filter = IntentFilter(ScreenCaptureService.ACTION_BOARD)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(boardReceiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(boardReceiver, filter)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 12)
            setBackgroundColor(0xFFFFF8E8.toInt())
        }
        val title = TextView(this).apply {
            text = "Gomoku Vision Pro  V2"
            textSize = 23f; setTextColor(0xFF4E342E.toInt())
        }
        status = TextView(this).apply { text = "导入截图，或启动实时屏幕识别"; textSize = 14f }
        boardView = BoardPreviewView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        liveButton = Button(this).apply {
            text = "开始实时屏幕识别"
            setOnClickListener { toggleCapture() }
        }
        val import = Button(this).apply {
            text = "导入截图识别"
            setOnClickListener { picker.launch("image/*") }
        }
        val ai = Button(this).apply {
            text = "AI 分析最佳落点"
            setOnClickListener { runAi() }
        }
        details = TextView(this).apply {
            textSize = 15f; setTextColor(0xFF1B5E20.toInt())
        }
        root.addView(title)
        root.addView(status)
        root.addView(boardView, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(liveButton)
        root.addView(import)
        root.addView(ai)
        root.addView(details)
        setContentView(root)
    }

    private fun toggleCapture() {
        if (liveButton.text.toString().startsWith("停止")) {
            stopService(Intent(this, ScreenCaptureService::class.java))
            liveButton.text = "开始实时屏幕识别"
            status.text = "实时识别已停止"
            return
        }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionConsent.launch(manager.createScreenCaptureIntent())
    }

    private fun detectImported() {
        val source = bitmap ?: return
        executor.execute {
            try {
                val result = BoardDetector.detect(source)
                board = result.board
                runOnUiThread {
                    boardView.state = result.board
                    boardView.recommended = null
                    status.text = "${result.message}  置信度 ${"%.0f".format(result.confidence * 100)}%"
                    details.text = "已重建 ${result.board.size}×${result.board.size} 棋盘。请检查识别结果后运行 AI。"
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "识别失败：${e.message}" }
            }
        }
    }

    private fun runAi() {
        val current = board?.copyBoard() ?: run { status.text = "请先识别棋盘"; return }
        status.text = "AI 搜索中…"
        executor.execute {
            try {
                val move = GomokuEngine(maxDepth = 5, nodeLimit = 350_000).bestMove(current)
                runOnUiThread {
                    recommended = move
                    boardView.recommended = move?.let { it.row to it.col }
                    details.text = if (move == null) "没有可用落点"
                    else "推荐 ${if (current.next == Stone.BLACK) "黑棋" else "白棋"}：第 ${move.col + 1} 列、第 ${move.row + 1} 行\n${move.reason}\n搜索评分：${move.score}"
                    status.text = "分析完成。绿色圆圈标出推荐位置；请自行确认落子。"
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "AI 分析失败：${e.message}" }
            }
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(boardReceiver) } catch (_: Exception) {}
        executor.shutdownNow()
        super.onDestroy()
    }
}
